module.exports = [
  {
    files: ["src/assets/js/**/*.js", "src/assets/js/**/*.cjs"],
    rules: {
      "quotes": ["error", "single"],
      "prefer-const": "error",
    },
  },
]
