// boolean 관련 기능
