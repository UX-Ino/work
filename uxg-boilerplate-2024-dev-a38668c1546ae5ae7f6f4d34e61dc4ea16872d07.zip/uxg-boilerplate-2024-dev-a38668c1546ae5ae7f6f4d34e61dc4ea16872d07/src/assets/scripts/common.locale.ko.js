// const etUI = {} || window.etUI;
// etUI.locale.ko = {
//   swiper: {
//     next: '다음',
//     prev: '이전'
//   }
// }
//
// etUI.locale.en = {
//   swiper: {
//     next: 'next',
//     prev: 'prev'
//   }
// }
//
// etUI.locale.defaultLocale = 'ko';
// etUI.locale.setLocale('ko')
